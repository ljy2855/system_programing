$make
$./myshell